//
//  AlanHint.h
//  AlanSDK
//
//  Copyright © 2019 Alan AI Inc. All rights reserved.
//  Alan Studio - https://studio.alan.app
//

#import <UIKit/UIKit.h>

@interface AlanHint: UIView

@end
