//
//  SecondViewController.swift
//  SwiftTutorial
//
//  Created by Sergey Yuryev on 06.07.2020.
//  Copyright © 2020 Alan AI. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
        
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    /// Once view is on the screen - send updated visual state to Alan
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        /// Get view controller with Alan button
        if let rootVC = self.view.window?.rootViewController as? ViewController {
            /// Send visual state via Alan button
            /// "screen" - our current application screen
            rootVC.setVisualState(state: ["screen": "second"])
        }
    }
    
}
