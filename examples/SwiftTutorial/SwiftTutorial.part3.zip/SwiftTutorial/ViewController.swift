//
//  ViewController.swift
//  SwiftTutorial
//
//  Created by Sergey Yuryev on 06.07.2020.
//  Copyright © 2020 Alan AI. All rights reserved.
//

import UIKit
import AlanSDK

class ViewController: UINavigationController {
    
    /// Alan button
    fileprivate var button: AlanButton!

    /// Alan text panel
    fileprivate var text: AlanText!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        /// Set up the Alan button
        self.setupAlan()
        
        /// Set up the handler for events from Alan
        self.setupAlanEventHandler()
    }
    
    
    // MARK: - Alan setup
    
    fileprivate func setupAlan() {
        /// Define project key
        let config = AlanConfig(key: "43a34ab97ace4470faceb579449bc5142e956eca572e1d8b807a3e2338fdd0dc/stage")
        
        ///  Init Alan button
        self.button = AlanButton(config: config)
        
        /// Init Alan text panel
        self.text = AlanText(frame: CGRect.zero)
        
        /// Add button and text panel to the window
        self.view.addSubview(self.button)
        self.button.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(self.text)
        self.text.translatesAutoresizingMaskIntoConstraints = false
        
        /// Aling button and text panel on the window
        let views = ["button" : self.button!, "text" : self.text!]
        let verticalButton = NSLayoutConstraint.constraints(withVisualFormat: "V:|-(>=0@299)-[button(64)]-40-|", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: views)
        let verticalText = NSLayoutConstraint.constraints(withVisualFormat: "V:|-(>=0@299)-[text(64)]-40-|", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: views)
        let horizontalButton = NSLayoutConstraint.constraints(withVisualFormat: "H:|-(>=0@299)-[button(64)]-20-|", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: views)
        let horizontalText = NSLayoutConstraint.constraints(withVisualFormat: "H:|-20-[text]-20-|", options: NSLayoutConstraint.FormatOptions(), metrics: nil, views: views)
        self.view.addConstraints(verticalButton + verticalText + horizontalButton + horizontalText)
    }
    
    fileprivate func setupAlanEventHandler() {
        /// Add observer to get events from Alan
        NotificationCenter.default.addObserver(self, selector: #selector(self.handleEvent(_:)), name:NSNotification.Name(rawValue: "kAlanSDKEventNotification"), object:nil)
    }
    
    
    // MARK: - Commands handler
    
    @objc func handleEvent(_ notification: Notification) {
        /// Get user info object with json from Alan
        guard let userInfo = notification.userInfo,
            let jsonString = userInfo["jsonString"] as? String,
            let jsonData = jsonString.data(using: .utf8),
            let jsonObject = try? JSONSerialization.jsonObject(with: jsonData, options: []) as? [String: Any],
            /// Get object with command data
            let commandObject = jsonObject["data"] as? [String: Any],
            /// Get command name string
            let commandString = commandObject["command"] as? String
        else {
            return
        }
        
        /// "navigation" command
        if commandString == "navigation" {
            /// Get route name string
            guard let routeString = commandObject["route"] as? String else {
                return
            }
            /// Forward command
            if routeString == "forward" {
                DispatchQueue.main.async {
                    self.goForward()
                }
            }
            /// Back command
            else if routeString == "back" {
                DispatchQueue.main.async {
                    self.goBack()
                }
            }
        }
    }
    
    
    // MARK: - Navigation
    
    fileprivate func goForward() {
        /// Get first view controller
        if let firstVC = self.viewControllers.first {
            /// Perform segue to push second view controller to the navigation stack. (Segue is defined in the storyboard)
            firstVC.performSegue(withIdentifier: "goForward", sender: self)
        }
    }
    
    fileprivate func goBack() {
        /// Remove second (last) view controller from the navigation stack
        self.popViewController(animated: true)
    }
    
    
    // MARK: - Visual state
    
    func setVisualState(state: [AnyHashable: Any]) {
        /// Call api "setVisualState"
        self.button.setVisualState(state)
    }
    
}

