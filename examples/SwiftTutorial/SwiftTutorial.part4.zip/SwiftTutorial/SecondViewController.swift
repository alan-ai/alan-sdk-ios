//
//  SecondViewController.swift
//  SwiftTutorial
//
//  Created by Sergey Yuryev on 06.07.2020.
//  Copyright © 2020 Alan AI. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    /// Table view to display data
    @IBOutlet weak var tableView: UITableView!
    
    /// Prepare some dummy data for table view
    fileprivate let items = ["one", "two", "three", "four", "five"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    /// Once view is on the screen - send updated visual state to Alan
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        /// Get view controller with Alan button
        if let rootVC = self.view.window?.rootViewController as? ViewController {
            /// Send visual state via Alan button
            /// "screen" - our current application screen
            /// "items" - data that is presented on this screen
            rootVC.setVisualState(state: ["screen": "second", "items": self.items])
        }
    }
    
    
    // MARK - Table view
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        /// Get item from dummy data array
        let item = self.items[indexPath.row]
        /// Prepare cell
        let cell = tableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath) as UITableViewCell
        /// Add text with item name to the cell
        cell.textLabel?.text = item
        /// Return the cell
        return cell
    }
    
    
    // MARK: - Highlight
    
    func highlightItem(item: String) {
        /// Index of item in dummy data array
        guard let itemIndex = self.items.firstIndex(of: item),
            /// Get cell by index
            let cell = self.tableView.cellForRow(at: IndexPath(row: itemIndex, section: 0))
        else {
            return
        }
        /// Highlight the cell
        cell.setHighlighted(true, animated: true)
        /// Schedule removing highlight after some time
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            /// Remove highlight from the cell
            cell.setHighlighted(false, animated: true)
        }
    }
}
